// InventoryApp.java
// [The Java code goes here — shortened here for brevity]