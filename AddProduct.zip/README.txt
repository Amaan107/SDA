# Inventory Management System - Add Item Module

This project is a simple GUI-based inventory management system built in Java using the MVC pattern. 
It connects to a MySQL database to allow the user to add items to the inventory.

## 💻 Technologies Used
- Java (Swing for GUI)
- MySQL
- JDBC Driver (mysql-connector-java)

## 📁 Files Included
- InventoryApp.java — Full Java code (Model, View, Controller, DAO, Main)
- inventory_schema.sql — SQL script to create the database and table
- README.txt — This file

## 📦 Requirements
- JDK 8 or above
- MySQL installed and running
- MySQL JDBC Driver (e.g., mysql-connector-java-8.0.xx.jar)

## 🏁 Setup Instructions

1. **Set Up MySQL Database**
   - Open MySQL Workbench or command line.
   - Run the `inventory_schema.sql` script to create the database and table.

2. **Configure Java File**
   - Open `InventoryApp.java`.
   - Change the `USER` and `PASS` in the `InventoryDAO` class to match your MySQL credentials.

3. **Download MySQL JDBC Driver**
   - [Download Here](https://dev.mysql.com/downloads/connector/j/)
   - Extract and place the JAR file in the same directory as `InventoryApp.java`.

4. **Compile and Run**

### Windows CMD
```
javac -cp .;mysql-connector-java-8.0.xx.jar InventoryApp.java
java -cp .;mysql-connector-java-8.0.xx.jar InventoryApp
```

### Mac/Linux Terminal
```
javac -cp .:mysql-connector-java-8.0.xx.jar InventoryApp.java
java -cp .:mysql-connector-java-8.0.xx.jar InventoryApp
```

## ✨ Features
- Add item with validation
- GUI form using JPanel
- MySQL database integration